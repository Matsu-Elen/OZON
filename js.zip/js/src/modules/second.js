const second = () => {
    const cartBtn = document.getElementById('cart')
    console.log('second')
}
export default second
/* const cartModal = document.querySelector('.cart')
const cartCloseBtn = cartModal.querySelector('.cart-close')
const openCart = () => {
    cartModal.style.display = 'flex'
}
const closeCart = () => {
    cartModal.style.display = ''
}

cartBtn.addEventListener('click', openCart)
cartCloseBtn.addEventListener('click',closeCart)
console.dir(cartCloseBtn) */